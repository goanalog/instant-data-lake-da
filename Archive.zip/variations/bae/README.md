# Base Variation — Instant Data Lake
This variation deploys:
- IBM Cloud Object Storage (Lite)
- Regional bucket
- Sample CSVs uploaded at deploy time
- Serverless Helper App built and deployed via Code Engine (public route)
- Shareable live URL as primary output
