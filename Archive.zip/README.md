# Instant Data Lake — IBM Cloud Deployable Architecture
Deploys COS (Lite) + regional bucket, uploads sample CSVs, and builds/deploys a serverless Helper App on Code Engine.
Primary output includes a shareable live URL.
