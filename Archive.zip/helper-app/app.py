import os
import json
import logging
from flask import Flask, render_template, jsonify
from ibm_secrets_manager_sdk.secrets_manager_v2 import SecretsManagerV2
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator, VpcInstanceAuthenticator, ContainerAuthenticator
from ibm_cloud_sdk_core.api_exception import ApiException # Import ApiException for specific error handling
# ibm_db requires DB2 drivers to be installed separately
# Ensure your Dockerfile handles this installation
try:
    import ibm_db
    IBM_DB_LOADED = True
except ImportError:
    print("-------------------------------------------------------------------------", flush=True)
    print("ERROR: ibm_db module not found.", flush=True)
    print("Ensure IBM Db2 drivers and the ibm_db Python package are installed in the container image.", flush=True)
    print("Refer to [https://github.com/ibmdb/python-ibmdb](https://github.com/ibmdb/python-ibmdb) for installation instructions.", flush=True)
    print("-------------------------------------------------------------------------", flush=True)
    # Allow app to start but DB operations will fail
    ibm_db = None
    IBM_DB_LOADED = False

# Add imports needed for safe JSON serialization if not already present
import datetime
import decimal


app = Flask(__name__)

# --- Configuration (Pulled from Environment Variables) ---
db2_hostname = os.environ.get('DB2_HOSTNAME')
db2_port = os.environ.get('DB2_PORT')
db2_database = os.environ.get('DB2_DATABASE', 'BLUDB')
db2_protocol = os.environ.get('DB2_PROTOCOL', 'TCPIP')
db2_uid = os.environ.get('DB2_UID', 'iamuser') # Using IAM authentication
db2_pwd_secret_crn = os.environ.get('DB2_PWD_SECRET_CRN') # CRN of the API key secret

# Secrets Manager URL: Prioritize binding, fallback to Terraform-provided URL
secrets_manager_url = os.environ.get('BINDING_SECRETS_MANAGER_URL', os.environ.get('SECRETS_MANAGER_URL'))

public_sample_data_url_base = os.environ.get('PUBLIC_SAMPLE_DATA_URL_BASE') # e.g., cos://us-east/your-public-bucket

# --- User Resource Info ---
user_cos_bucket_name = os.environ.get('USER_COS_BUCKET_NAME', '#N/A#')
user_cos_bucket_url = os.environ.get('USER_COS_BUCKET_URL', '#')
user_db2_console_url = os.environ.get('USER_DB2_CONSOLE_URL', '#')
user_helper_app_console_url = os.environ.get('USER_HELPER_APP_CONSOLE_URL', '#')
user_secrets_manager_url = os.environ.get('USER_SECRETS_MANAGER_URL', '#') # Link to SM instance UI
deployed_region = os.environ.get('DEPLOYED_REGION', '#N/A#')

# --- Global Variables ---
db2_api_key = None # Will be fetched from Secrets Manager
db2_conn = None # Global connection object

# --- Logging ---
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Helper Functions ---

def get_secrets_manager_authenticator():
    """ Determines the best authenticator for Secrets Manager based on env vars """
    # Priority 1: Use Code Engine binding API Key if present
    binding_apikey = os.environ.get('BINDING_SECRETS_MANAGER_APIKEY')
    if binding_apikey:
        logging.info("Using Code Engine binding API key for Secrets Manager authentication.")
        return IAMAuthenticator(binding_apikey)

    # Priority 2: Use generic IBMCLOUD_API_KEY if present (less ideal, requires Terraform to pass it, which isn't standard for CE)
    generic_apikey = os.environ.get('IBMCLOUD_API_KEY')
    if generic_apikey:
        logging.warning("Using IBMCLOUD_API_KEY for Secrets Manager authentication (fallback). Ensure this is securely passed if not using binding.")
        return IAMAuthenticator(generic_apikey)

    # Add other authenticators if relevant for other environments (VPC, Container)
    # authenticator = VpcInstanceAuthenticator(...)
    # authenticator = ContainerAuthenticator(...)

    logging.error("No suitable authenticator found for Secrets Manager. Neither BINDING_SECRETS_MANAGER_APIKEY nor IBMCLOUD_API_KEY environment variables were set.")
    return None


def get_db2_api_key():
    """Fetches the Db2 API Key from IBM Cloud Secrets Manager."""
    global db2_api_key
    if db2_api_key:
        return db2_api_key

    if not db2_pwd_secret_crn or not secrets_manager_url:
        logging.error("Secrets Manager CRN or URL not configured via environment variables (DB2_PWD_SECRET_CRN, SECRETS_MANAGER_URL/BINDING_SECRETS_MANAGER_URL).")
        return None

    authenticator = get_secrets_manager_authenticator()
    if not authenticator:
        logging.error("Failed to create Secrets Manager authenticator.")
        return None

    try:
        secrets_manager = SecretsManagerV2(authenticator=authenticator)
        secrets_manager.set_service_url(secrets_manager_url)

        # Parse CRN to get Secret ID
        parts = db2_pwd_secret_crn.split(':')
        if len(parts) < 9 or parts[7] != 'secret':
             logging.error(f"Invalid Secret CRN format received: {db2_pwd_secret_crn}")
             raise ValueError(f"Invalid Secret CRN format")
        secret_id = parts[8]

        logging.info(f"Attempting to get secret by ID: {secret_id} from {secrets_manager_url}")
        # Assuming Terraform created an 'iam_credentials' type secret which is often preferred for API keys
        response = secrets_manager.get_secret(
            secret_type='iam_credentials', # Explicitly try iam_credentials first
            id=secret_id
        )
        secret_data = response.get_result()
        api_key_value = secret_data.get('secret_data', {}).get('apikey')

        # Fallback to 'arbitrary' type if 'iam_credentials' didn't work or wasn't used
        if not api_key_value:
            logging.warning("API key not found assuming 'iam_credentials' type, trying 'arbitrary' type...")
            response = secrets_manager.get_secret(
                secret_type='arbitrary',
                id=secret_id
            )
            secret_data = response.get_result()
            api_key_value = secret_data.get('secret_data', {}).get('payload') # Common field for arbitrary

        if not api_key_value:
             logging.error("API Key not found in secret payload using either 'iam_credentials' (field 'apikey') or 'arbitrary' (field 'payload'). Check secret configuration in Terraform and Secrets Manager.")
             raise ValueError("API Key not found in secret payload.")

        db2_api_key = api_key_value
        logging.info("Successfully retrieved Db2 API Key from Secrets Manager.")
        return db2_api_key

    except ApiException as e:
        logging.error(f"Secrets Manager API error fetching secret (ID: {secret_id}): {e.code} - {e.message}")
        logging.error("Check IAM permissions for the Code Engine app/service ID on the Secrets Manager instance and the specific secret.")
        return None
    except ValueError as e: # Catch specific ValueError from CRN parsing or missing key
         logging.error(f"Configuration error fetching secret: {e}")
         return None
    except Exception as e:
        logging.error(f"Unexpected error fetching secret from Secrets Manager: {e}")
        return None

def get_db2_connection():
    """Establishes or returns the existing Db2 connection."""
    global db2_conn
    if db2_conn:
        try:
            # More robust check: Execute a simple query
            stmt = ibm_db.exec_immediate(db2_conn, "SELECT 1 FROM SYSIBM.SYSDUMMY1")
            if stmt is not None:
                ibm_db.free_result(stmt) # Clean up
                logging.debug("Reusing existing active Db2 connection.")
                return db2_conn
            else:
                 raise Exception("Connection check query failed.")
        except Exception as e:
            logging.warning(f"Existing connection check failed or connection lost: {e}. Reconnecting.")
            try:
                ibm_db.close(db2_conn) # Attempt to close gracefully
            except:
                pass # Ignore errors during close
            db2_conn = None # Force reconnect

    # Check if ibm_db loaded successfully at startup
    if not IBM_DB_LOADED or not ibm_db:
        logging.error("ibm_db module not loaded. Cannot connect to Db2.")
        return None, "Db2 Driver Error: ibm_db module not loaded. Check container build/logs." # Return error message

    api_key = get_db2_api_key()
    if not api_key:
        # Error logged in get_db2_api_key()
        return None, "Db2 Connection Failed: Could not retrieve API Key from Secrets Manager." # Return error message

    if not all([db2_hostname, db2_port, db2_database]):
        logging.error("Db2 connection details (hostname, port, database) missing in environment variables.")
        return None, "Db2 Connection Failed: Connection details missing (hostname, port, database)." # Return error message

    # Standard SSL Cert path within driver install directory
    ssl_cert_path = "/opt/dsdriver/cfg/DigiCertGlobalRootCA.arm" # Adjusted based on common driver install path
    ssl_cert_param = "" # Initialize
    # Check if cert exists at the expected path within the container
    if os.path.exists(ssl_cert_path):
        ssl_cert_param = f"SSLServerCertificate={ssl_cert_path};"
        logging.info(f"Using SSL certificate found at: {ssl_cert_path}")
    else:
         logging.warning(f"SSL Cert path not found: {ssl_cert_path}. Connection will rely on system trust store.")


    conn_string = (
        f"DATABASE={db2_database};"
        f"HOSTNAME={db2_hostname};"
        f"PORT={db2_port};"
        f"PROTOCOL={db2_protocol};"
        f"UID={db2_uid};"
        f"PWD={api_key};"
        f"SECURITY=SSL;" # Db2 Warehouse on Cloud requires SSL
        f"AUTHENTICATION=GSS_PLUGIN;"
        f"PLUGINNAME=IBMIAMauth;"
        f"{ssl_cert_param}" # Append SSL cert parameter if path found
    )

    try:
        logging.info(f"Attempting to connect to Db2: {db2_hostname}:{db2_port}, Database: {db2_database}")
        db2_conn = ibm_db.connect(conn_string, "", "")
        logging.info("Successfully connected to Db2.")
        return db2_conn
    except Exception as e:
        # Provide more specific feedback if possible
        error_code = str(e) # ibm_db often includes SQLCODE in the error string
        logging.error(f"Db2 connection failed: {error_code}")
        db2_conn = None
        # Map common errors to user-friendly messages
        if "SQLCODE=-1391" in error_code or "SQLCODE=-30082" in error_code:
            return None, "Db2 Connection Failed: Authentication error. Check API Key or IAM permissions for the Service ID on the Db2 instance."
        elif "SQLCODE=-1097" in error_code or "SQLCODE=-1031" in error_code:
             return None, "Db2 Connection Failed: Database server unavailable or hostname/port incorrect. Verify Db2 instance is running."
        elif "SSL" in error_code.upper():
             # Provide more context if cert path was used
             ssl_info = f"Path tried: {ssl_cert_path}" if ssl_cert_param else "Relying on system trust store."
             return None, f"Db2 Connection Failed: SSL error. Certificate issue? {ssl_info}"
        else:
            return None, f"Db2 Connection Failed: {error_code}" # Generic fallback


def execute_sql(sql_command):
    """Executes a SQL command against the Db2 database."""
    # Check driver first
    if not IBM_DB_LOADED:
        return False, "Db2 Driver Error: ibm_db module failed to load. Check container logs."

    conn_result = get_db2_connection()
    # Check if get_db2_connection returned a tuple (error case)
    if isinstance(conn_result, tuple):
        conn, error_message = conn_result
        if conn is None:
            return False, error_message # Return specific connection error
    else:
        conn = conn_result # Normal connection object

    if not conn:
        return False, "Db2 Connection Error: Failed to establish connection." # Fallback generic message

    stmt = None # Initialize statement handle
    try:
        logging.info(f"Executing SQL: {sql_command[:100]}...") # Log truncated SQL
        stmt = ibm_db.exec_immediate(conn, sql_command)
        # Check for errors after execution attempt
        if stmt is None:
           # Get specific error message from the failed connection attempt
           error_msg = ibm_db.conn_errormsg() if ibm_db.conn_error() else "Unknown execution error"
           raise Exception(error_msg)

        logging.info("SQL command executed successfully.")
        return True, "Command executed successfully."
    except Exception as e:
        error_msg = f"SQL Execution Error: {e}"
        logging.error(error_msg)
        # Add common SQL errors if needed
        if "SQLCODE=-601" in str(e): # Object already exists
            return False, f"SQL Execution Failed: Object likely already exists. ({e})"
        return False, error_msg
    finally:
         # Attempt to close statement handle if one was created
        if stmt is not None:
            try:
                ibm_db.free_stmt(stmt)
            except Exception as free_e:
                logging.warning(f"Could not free Db2 statement handle: {free_e}")


def fetch_sql_results(sql_query):
    """Executes a SELECT SQL query and fetches results."""
    # Check driver first
    if not IBM_DB_LOADED:
        return None, "Db2 Driver Error: ibm_db module failed to load. Check container logs."

    conn_result = get_db2_connection()
    # Check if get_db2_connection returned a tuple (error case)
    if isinstance(conn_result, tuple):
        conn, error_message = conn_result
        if conn is None:
            return None, error_message # Return specific connection error
    else:
        conn = conn_result # Normal connection object

    if not conn:
        return None, "Db2 Connection Error: Failed to establish connection." # Fallback generic message

    results = []
    stmt = None # Initialize stmt
    try:
        logging.info(f"Fetching SQL: {sql_query[:100]}...") # Log truncated SQL
        stmt = ibm_db.exec_immediate(conn, sql_query)

        if stmt is None:
           error_msg = ibm_db.conn_errormsg() if ibm_db.conn_error() else "Unknown query execution error"
           raise Exception(error_msg)

        # Get column names
        column_names = []
        num_fields = ibm_db.num_fields(stmt)
        if num_fields > 0:
             for i in range(num_fields):
                 col_name = ibm_db.field_name(stmt, i)
                 if col_name: # Ensure column name is valid
                     column_names.append(col_name)
                 else:
                     logging.warning(f"Could not retrieve name for column index {i}")
                     column_names.append(f"COLUMN_{i}") # Use placeholder


             # Fetch rows
             row = ibm_db.fetch_assoc(stmt)
             while row is not False: # fetch_assoc returns False when no more rows
                 # Process row values
                 processed_row = {}
                 for col in column_names:
                     # Check if column exists in fetched row (can happen with invalid col names)
                     if col in row:
                         # Convert common non-serializable types safely
                         val = row[col]
                         if isinstance(val, (datetime.date, datetime.datetime)):
                             processed_row[col] = val.isoformat()
                         elif isinstance(val, decimal.Decimal):
                              processed_row[col] = float(val) # Or str(val) if precision needed
                         # Handle binary types if they appear (rare for CSV query)
                         elif isinstance(val, bytes):
                              processed_row[col] = '<binary data>' # Placeholder
                         else:
                              # Convert everything else to string safely
                              processed_row[col] = str(val) if val is not None else None
                     else:
                         processed_row[col] = None # Placeholder if column name wasn't fetched correctly

                 results.append(processed_row)
                 row = ibm_db.fetch_assoc(stmt)

        logging.info(f"SQL query fetched {len(results)} rows.")
        return results, "Query executed successfully."

    except Exception as e:
        error_msg = f"SQL Query Error: {e}"
        logging.error(error_msg)
        # Add common SQL errors if needed
        if "SQLCODE=-204" in str(e): # Object not found
            return None, "SQL Query Failed: Table or object not found. Was the setup step run?"
        return None, error_msg
    finally:
        # Ensure statement resources are freed
        if stmt is not None:
             try:
                 ibm_db.free_result(stmt) # Preferred over free_stmt for SELECT
             except Exception as free_e:
                 logging.warning(f"Error freeing Db2 statement result: {free_e}")

# --- Flask Routes ---

@app.route('/')
def index():
    """Serves the main HTML page, passing resource info."""
    # Ensure Db2 driver loaded check
    driver_status = "OK" if IBM_DB_LOADED else "Error: Db2 driver (ibm_db) failed to load. Check container build/logs."

    resource_links = {
        "cos_bucket_name": user_cos_bucket_name,
        "cos_bucket_url": user_cos_bucket_url,
        "db2_console_url": user_db2_console_url,
        "helper_app_console_url": user_helper_app_console_url,
        "secrets_manager_url": user_secrets_manager_url,
        "region": deployed_region,
        "driver_status": driver_status # Add driver status
    }
    return render_template('index.html', links=resource_links)

@app.route('/setup', methods=['POST'])
def setup_table():
    """API endpoint to run the CREATE EXTERNAL TABLE command."""
    # Check driver first
    if not IBM_DB_LOADED:
        return jsonify({"status": "Error", "message": "Db2 driver (ibm_db) is not loaded. Cannot perform setup. Check container logs."}), 500

    if not public_sample_data_url_base:
        return jsonify({"status": "Error", "message": "Configuration Error: Public sample data URL base not set."}), 400

    # Define SQL commands
    # IMPORTANT: Ensure column definitions EXACTLY match customers.csv header and data types
    create_sql = f"""
    CREATE EXTERNAL TABLE SAMPLE_CUSTOMERS (
        CustomerID INT, FirstName VARCHAR(50), LastName VARCHAR(50), Company VARCHAR(100),
        City VARCHAR(50), Country VARCHAR(50), Phone1 VARCHAR(30), Phone2 VARCHAR(30),
        Email VARCHAR(100), SubscriptionDate DATE, Website VARCHAR(100)
    ) USING (
        DATAOBJECT('{public_sample_data_url_base}/customers.csv')
        FORMAT CSV DELIMITER ',' QUOTE '"' SKIPHEADER 1 LOGERRORS TRUE REMOTESOURCE 'COS' CTRLCHARS TRUE
    )"""
    # Use Db2 system catalog view SYSCAT.TABLES
    # Ensure schema matches Db2 Warehouse user ID if not explicitly qualified
    # Default schema is usually username, e.g., 'IAMUSER' or similar
    check_sql = "SELECT 1 FROM SYSCAT.TABLES WHERE TABSCHEMA = CURRENT SCHEMA AND TABNAME = 'SAMPLE_CUSTOMERS'"

    # Check existence first for idempotency
    table_exists = False
    stmt_check = None # Initialize handle
    try:
        conn_result = get_db2_connection()
        # Handle potential connection error tuple
        if isinstance(conn_result, tuple):
             conn, error_message = conn_result
             if conn is None: return jsonify({"status": "Error", "message": error_message}), 500
        else:
             conn = conn_result
        if not conn: return jsonify({"status": "Error", "message": "Db2 Connection Error: Failed to establish connection"}), 500

        logging.info("Checking if SAMPLE_CUSTOMERS table exists...")
        stmt_check = ibm_db.exec_immediate(conn, check_sql)
        if stmt_check is None:
            raise Exception(f"Failed to execute table check: {ibm_db.conn_errormsg()}")

        exists = ibm_db.fetch_tuple(stmt_check) # Returns tuple if row found, None otherwise

        if exists: # Check if a row was returned
            table_exists = True
            logging.info("Table SAMPLE_CUSTOMERS already exists. Skipping creation.")
            return jsonify({"status": "OK", "message": "Sample table link already exists."})
        else:
            logging.info("Table SAMPLE_CUSTOMERS does not exist yet. Proceeding with creation.")

    except Exception as e:
         # Log the specific error during the check
         logging.error(f"Error checking if table exists (will attempt create anyway): {e}")
         # If the error isn't simply 'table not found', maybe return an error?
         if "SQLCODE=-204" not in str(e): # -204 is 'object not found' - expected if table doesn't exist
             return jsonify({"status": "Error", "message": f"Failed to check table existence: {e}"}), 500
         # Otherwise (it was -204), log and proceed to create
         logging.info("Table check returned 'not found' (SQLCODE=-204), proceeding with creation.")
    finally:
        # Ensure check statement is freed
        if stmt_check is not None:
             try:
                 ibm_db.free_result(stmt_check) # Use free_result for SELECTs
             except Exception as free_e:
                 logging.warning(f"Could not free Db2 check statement result: {free_e}")


    # Proceed with CREATE TABLE only if the check confirmed it doesn't exist
    if not table_exists:
        logging.info("Attempting to create external table SAMPLE_CUSTOMERS...")
        success, message = execute_sql(create_sql)
        if success:
            logging.info("External table SAMPLE_CUSTOMERS created successfully.")
            return jsonify({"status": "OK", "message": "Sample table link created successfully!"})
        else:
            # Check for specific "already exists" error - defensive check in case check logic failed
            if "SQLCODE=-601" in message:
                 logging.warning("CREATE TABLE failed because table already exists (check logic might have failed or race condition).")
                 return jsonify({"status": "OK", "message": "Sample table link already exists (race condition?)."})
            logging.error(f"Failed to create external table: {message}")
            return jsonify({"status": "Error", "message": f"Failed to create table link: {message}"}), 500

    # Fallback if somehow table_exists was true but initial return didn't happen
    logging.warning("Reached fallback return in /setup - table likely already existed.")
    return jsonify({"status": "OK", "message": "Sample table link already existed (fallback)."}), 200


@app.route('/query', methods=['POST'])
def query_data():
    """API endpoint to run the sample SELECT query."""
     # Check driver first
    if not IBM_DB_LOADED:
        return jsonify({"status": "Error", "message": "Db2 driver (ibm_db) is not loaded. Cannot query data. Check container logs."}), 500

    select_sql = "SELECT CustomerID, FirstName, LastName, Country FROM SAMPLE_CUSTOMERS WHERE Country = 'USA' LIMIT 10"

    results, message = fetch_sql_results(select_sql)

    if results is not None:
        # Successfully got results (even if empty list)
        return jsonify({"status": "OK", "message": f"Query successful! Found {len(results)} rows.", "data": results})
    else:
        # fetch_sql_results indicated an error
        # Check if the error is specifically "table not found"
        if "SQLCODE=-204" in message or "Table or object not found" in message:
             logging.warning("Query failed because SAMPLE_CUSTOMERS table was not found.")
             return jsonify({"status": "Error", "message": "Sample table not found. Please click 'Prepare Sample Data Table' first, wait a moment, then try again."}), 400 # Bad Request
        # Return specific connection errors if they occurred during fetch
        elif "Db2 Connection Failed" in message:
             logging.error(f"Query failed due to Db2 connection error: {message}")
             return jsonify({"status": "Error", "message": message}), 500 # Internal Server Error
        else:
            # Generic query failure
            logging.error(f"Query failed with message: {message}")
            return jsonify({"status": "Error", "message": f"Query failed: {message}"}), 500


if __name__ == '__main__':
    # Add imports needed for safe JSON serialization if not already present
    import datetime
    import decimal

    # Attempt to fetch API key on startup - log error but don't prevent startup
    if not get_db2_api_key():
        logging.error("Failed to retrieve Db2 API Key on startup. Database operations will fail until resolved.")

    # Port needs to be 8080 for Code Engine by default unless overridden
    port = int(os.environ.get('PORT', 8080))
    # Run on 0.0.0.0 to be accessible within Code Engine
    logging.info(f"Starting Flask app on 0.0.0.0:{port}")
    # Use Gunicorn in production (as per Dockerfile CMD), but Flask dev server for local testing if run directly.
    # The CMD in Dockerfile takes precedence when run in container.
    # app.run(host='0.0.0.0', port=port) # Keep commented out if using Gunicorn via Docker CMD
